from django.db import models

# Create your models here.

class Aircraft(models.Model):
  name = models.CharField(max_length=255, default=None)
  capacity = models.IntegerField()
  

