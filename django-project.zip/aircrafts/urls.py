
from django.urls import path
from aircrafts import views

urlpatterns = [
    path("aircrafts/all/", views.get_aircrafts),
    path("aircrafts/create/", views.create_aircraft),
    path("aircrafts/update/<int:id>", views.update_aircraft),
    path("aircrafts/delete/<int:id>", views.delete_aircraft),
]
