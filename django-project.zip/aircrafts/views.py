from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

from . import models




### aircrafts

def get_aircrafts(request):
    data=models.Aircraft.objects.all()
    return HttpResponse(data)
   
def create_aircraft(request):
    if request.method=="POST":
        obj=models.Aircraft.objects.create(name=request.POST['name'],capacity=request.POST['capacity'])
        obj.save()
        return HttpResponse("Aircraft Stored Successfully!")
    else:
        return HttpResponse("Invalid Request Method!")
    
def update_aircraft(request, id):
    if request.method=="POST":
        try:
            obj=models.Aircraft.objects.get_object_or_404(id=id)
            obj.name = "sssssssss"
            ## obj.capacity = request.POST['capacity']
            obj.save()
            return HttpResponse("Aircraft Updated Successfully!")
        except :
            return HttpResponse("Aircraft Not Found!")
    else:
        return HttpResponse("Invalid Request Method!")
    
def delete_aircraft(request, id):
    try:
        models.Aircraft.objects.filter(id=id).delete()
        return HttpResponse("Aircraft Deleted Successfully!")
    except:
        return HttpResponse("Aircraft Not Found!")


