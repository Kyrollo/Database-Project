from django.db import models
from aircrafts.models import Aircraft
# Create your models here.

  
class Flight(models.Model):
  date = models.DateTimeField()
  available_seats = models.IntegerField()
  airport = models.CharField(max_length=255, default=None)
  source = models.CharField(max_length=255, default=None)
  destination = models.CharField(max_length=255, default=None)
  ticket_price = models.FloatField()
  aircraft = models.ForeignKey(Aircraft, on_delete = models.CASCADE)



