
from django.urls import path
from flights import views

urlpatterns = [
    path("flights/all/", views.get_flights),

]
