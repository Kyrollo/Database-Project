from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

from . import models




### aircrafts

def get_flights(request):
    data=models.Flight.objects.all()
    return HttpResponse(data)
   
