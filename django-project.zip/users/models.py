from django.db import models

# Create your models here.


class User(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  phone = models.CharField(max_length=255, default=None)
  email = models.EmailField(default=None)
  password = models.CharField(max_length=255, default=None)
  address = models.CharField(max_length=255, default=None, blank=True, null=True)
  role = models.CharField(max_length=255, default=None)